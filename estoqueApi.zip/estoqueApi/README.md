## Estrutura do Projeto
    .
    ├── .mvn                                            # Arquivos auxiliares do Maven
    ├── code                                            # Sub-diretório contendo as integrações
    │   └── [Integracao]                                # Código específico de cada integração
    │       │── src
    │       │   └── main
    │       │       │── docker                          # Arquivos Dockerfile para geração de container
    │       │       │── java                            
                    │   └─ br/com/malwee/Routes.java    # Contém as rotas do Camel
                    │── kubernetes 
                    │   └─ kubernetes.yml               # Template de resources do kubernetes
    │       │       └─── resources
    │       │            └─ application.properties      # Configurações do Quarkus
    │       └── pom.xml                                 # Configuração da integração via Maven
    ├── .dockerignore                                   
    ├── .gitignore                                      
    ├── mvnw                                            # Script para executar o maven (macos/linux)
    └── mvnw.cmd                                        # Script para executar o maven (windows)

### Arquivo de configuração POM
É o arquivo de configuração utilizado pelo Maven

### Atributos na raiz
* groupId  
  Nome do grupo de integração, normalmente `br.com.malwee`
* artifactId  
  Nome único da integração, utilizar apenas [a-zA-Z0-9-]
* version  
  Versão da integração, alterada todas vez que for feito um novo deploy
* name  
  Nome visual da integração (Livre)
* description  
  Descrição da integração (Livre)

### Propriedades importantes
* camel-quarkus.version  
  Indica qual versão do camel-quarkus será utilizado, ele esta associado com a versão do camel e quarkus

* quarkus-plugin.version  
  Versão do plugin do quarkus, deve seguir a versão indicada para a versão do `camel-quarkus`

### Dependências
Todos os pacotes utilizados pelo camel deve ser incluído no bloco `<dependencies>`



# Rodar um integração em modo dev

```shell script
../../mvnw compile quarkus:dev
../../mvnw compile quarkus:dev -Dquarkus.http.port=9090 -Ddebug=false
```

> **_NOTE:_**  Quarkus tem uma Dev UI, que esta disponivel em modo dev em http://localhost:8080/q/dev/.


# Empacotando a integração para deploy

```shell script
../../mvnw clean package -Dquarkus.container-image.build=true -Dquarkus.container-image.push=true
```
Irá fazer o package do projeto, gerar o container docker e enviar para o registry configurado



## Deploy no K8s
Dentro da pasta `src\main\kubernetes` esta localizado o arquivo base, `kubernetes.yml`, para geração do deploy via Kubernetes, ele deve ser customizado de acordo com a necessidade. 

Por padrão ele gera:
* ConfigMap  
  Contendo a configuração não sigilosas da integração, sera montando dentro do deployment na pasta /deployment/config
* Deployment  
  Para execução da integração
* Service  
  Para expor a integração caso seja necessário
* ServiceMonitor  
  Para auto descobrimento do Prometheus para monitoramento

**Dados sigilos. Ex: senhas de acesso**
Criar secret no kubernetes e mapear no deployment variável de ambiente `valueFrom`, podendo sobrepor diretamente uma configuração padrão do Quarkus
```
spec:
  containers:
  - env:
      - name: QUARKUS_DATASOURCE_PASSWORD
        valueFrom:
          secretKeyRef:
            name: mysecret
            key: password
```

Para desenvolvimento local pode-se usar um arquivo `.env` com os dados sigilos, ele será ignorado no git.
```
QUARKUS_DATASOURCE_PASSWORD=minha_senha_secreta
```
ou
```
quarkus.datasource.password=minha_senha_secreta
```

Após o `mvnw package` será gerado uma pasta `target\kubernetes` o arquivo `kubernetes.yml` para deploy no cluster.
```
kubectl apply -f target/kubernetes/kubernetes.yml
```
Obs: Se já existir um deploy da mesma integração no k8s deve ser removido antes de ser aplicado o novo arquivo `.yml`
```
kubectl delete service/[NOME] deploy/[NOME] servicemonitor/[NOME]
```
