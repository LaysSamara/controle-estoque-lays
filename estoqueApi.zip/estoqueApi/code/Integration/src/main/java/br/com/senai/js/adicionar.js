const criarItemElement = (item) => {
  //conectar no elemento template
  const template = document.getElementById('item-template')

  //clonar template
  const itemElement = document.importNode(template.content, true)

  //preencher os dados
  const itens_span = itemElement.querySelectorAll('span')

  itens_span[1].innerText = item.nome_item
  itens_span[2].innerText = item.descricao
  itens_span[3].innerText = item.quantidade
  itens_span[4].innerText = item.valor
  itens_span[5].innerText = item.setor

  return itemElement

}

const novoItem = async () => {
  const nomeElement = document.getElementById("nome");
  const descricaoElement = document.getElementById("descricao");
  const quantidadeElement = document.getElementById("quantidade");
  const valorElement = document.getElementById("valor");
  const setorElement = document.getElementById("setor");

  const produto = {
    nome_item: nomeElement.value,
    descricao: descricaoElement.value,
    quantidade: Number(quantidadeElement.value),
    valor: Number(valorElement.value),
    setor: setorElement.value
  }

  const init = {
    method: 'POST',
    headers: {
      "Content-Type": 'application/json'
    },
    body: JSON.stringify(produto)
  }

  //Chamar POST na API
  const response = await fetch('http://localhost:8080/adicionarItem')
  const dados = await response.json()

  //Adiciona novo filme à listagem
  const containerItensElement = document.getElementById('container-itens')

  const itemElement = criarItemElement(dados)

  //Adiciona o elemento item ao Container de Item
  containerItensElement.append(itemElement)

}

window.onload = () => {
  const btnNovoItem = document.getElementById('novoItem')

  btnNovoItem.onclick = novoItem

  console.log('Adicionar')
}








const form = document.getElementById("form");
const codigo = document.getElementById("codigo");
const nome = document.getElementById("nome");
const descricao = document.getElementById("descricao");
const quantidade = document.getElementById("quantidade");
const valor = document.getElementById("valor");
const setor = document.getElementById("setor");

form.addEventListener("submit", (e) => {
  e.preventDefault();

  checkInputs();
});

function checkInputs() {
  const codigoValue = codigo.value;
  const nomeValue = nome.value;
  const descricaoValue = descricao.value;
  const quantidadeValue = quantidade.value;
  const valorValue = valor.value;
  const setorValue = setor.value;

  if (codigoValue === "") {
    setErrorFor(codigo, "O código do item é obrigatório.");
  } else {
    setSuccessFor(codigo);
  }

  if (nomeValue === "") {
    setErrorFor(nome, "O nome do item é obrigatório.");
  } else {
    setSuccessFor(nome);
  }

  if (descricaoValue === "") {
    setErrorFor(descricao, "A descrição do produto é obrigatória.");
  } else {
    setSuccessFor(descricao);
  }

  if (quantidadeValue === "") {
    setErrorFor(quantidade, "A quantidade é obrigatória.");
  } else {
    setSuccessFor(quantidade);
  }

  if (valorValue === "") {
    setErrorFor(valor, "O valor do item é obrigatório.");
  } else {
    setSuccessFor(valor);
  }

  if (setorValue === "") {
    setErrorFor(setor, "O setor do produto é obrigatório.");
  } else {
    setSuccessFor(setor);
  }

  const formControls = form.querySelectorAll(".form-control");

  const formIsValid = [...formControls].every((formControl) => {
    return formControl.className === "form-control success";
  });

  if (formIsValid) {
    window.location.replace("../html/adicionado.html")
  }
}

function setErrorFor(input, message) {
  const formControl = input.parentElement;
  const small = formControl.querySelector("small");

  // Adiciona a mensagem de erro
  small.innerText = message;

  // Adiciona a classe de erro
  formControl.className = "form-control error";
}

function setSuccessFor(input) {
  const formControl = input.parentElement;

  // Adicionar a classe de sucesso
  formControl.className = "form-control success";
}