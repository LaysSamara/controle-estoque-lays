fetch ("http://localhost:8080/listarItem", { 
    method : "GET", 
    headers: {
        'id_item': 2
    }
})
.then (res => res.json())
.then (res => {
    console.log(res[0].id_item)
    console.log(res[0].nome_item)
    console.log(res[0].descricao)
    console.log(res[0].quantidade)
    console.log(res[0].valor)
    console.log(res[0].setor)
    const codigo = document.getElementById("codigo");
    const nome = document.getElementById("nome");
    const descricao = document.getElementById("descricao");
    const quantidade = document.getElementById("quantidade");
    const valor = document.getElementById("valor");
    const setor = document.getElementById("setor");

    codigo.innerText = res[0].id_item,
    nome.innerText = res[0].nome_item,
    descricao.innerText = res[0].descricao,
    quantidade.innerText = res[0].quantidade,
    valor.innerText = res[0].valor,
    setor.innerText = res[0].setor
});